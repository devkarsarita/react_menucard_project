import React from 'react';
import Resturant from "./component/Resturant";
const App = () => {
  return (
    
    <>
    <Resturant />
    </>
    
  );
};



export default App
