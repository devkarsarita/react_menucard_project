const Menu = [{
    id:1,
    image: "images/maggi.jpg",
    name: "maggie",
    category: "breakfast",
    price:"Rs.25",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in .",
},


{
    id: 2,
    image: "../images/samosa.jpg",
    name: "Samosa",
    category: "snacks",
    price: "Rs 10",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in .",
  },
  {
    id: 3,
    image: "images/vadapaav.jpg",
    name: "Vadapav",
    category: "breakfast",
    price: "Rs 10",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 4,
    image: "../images/chole-bhature.jpg",
    name: "Chole Bhature",
    category: "lunch",
    price: "Rs 50",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 5,
    image: "../images/pizza.jpg",
    name: "Pizza",
    category: "snacks",
    price: "Rs 80",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 6,
    image: "../images/non-veg_thali.jpg",
    name: "Chicken Thali",
    category: "dinner",
    price: "Rs 180",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 7,
    image: "../images/gulabjamun.jpg",
    name: "Gulabjamun",
    category: "dinner",
    price: "Rs. 30",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 8,
    image: "../images/rajma-chawal.jpg",
    name: "Rajma chawal",
    category: "lunch",
    price: "Rs. 60",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 9,
    image: "images/chaha.jpg",
    name: "Chaha",
    category: "breakfast",
    price: "Rs 10",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 10,
    image: "images/burger.jpg",
    name:"Burger",
    category: "snacks",
    price: "Rs 50",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 11,
    image: "images/coffe.jpg",
    name: "Coffee",
    category: "breakfast",
    price: "Rs 15",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 12,
    image: "images/donuts.jpg",
    name: "Donuts",
    category: "snacks",
    price: "Rs. 15/ pc",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 13,
    image: "images/momos.jpg",
    name: "Momos",
    category: "snacks",
    price: "Rs 60",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  }, 
  {
    id: 14,
    image: "images/french-fries.jpg",
    name: "French-fries",
    category: "snacks",
    price: "Rs 40",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  }, 
  {
    id: 15,
    image: "images/pancake.jpg",
    name: "Pancake",
    category: "breakfast",
    price: "Rs 30",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  }, 
  {
    id: 16,
    image: "images/pastry.jpg",
    name: "Pastry",
    category: "snacks",
    price: "Rs 40",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  }, 
  {
    id: 17,
    image: "images/prawns.jpg",
    name: "Fried Prawns",
    category: "dinner",
    price: "Rs 150",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  }, 
  {
    id: 18,
    image: "images/smoothi.jpg",
    name: "smoothi",
    category: "snacks",
    price: "Rs 80",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  },
  {
    id: 19,
    image: "images/sushi.jpg",
    name: "Sushi",
    category: "dinner",
    price: "Rs 90",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, at consectetur totam voluptatibus quibusdam iusto. Accusamus quas, soluta ipsam autem eius necessitatibus fugiat in . ",
  }, 
];



export default Menu;